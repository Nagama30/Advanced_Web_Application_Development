import React from "react";
import TodoList from "./ToDoList";

function App() {
  return (
    <div className="App">
      <TodoList />
    </div>
  );
}

export default App;
